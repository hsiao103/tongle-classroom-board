﻿param([string]$u)
# cbopen: open local folders/files in Explorer. Executables are only revealed, never run.
$p=[uri]::UnescapeDataString(($u -replace '^cbopen:/*','')).Trim().Trim('"')
if($p -notmatch '^([A-Za-z]:\\|\\\\[^\\])'){exit}
if(-not (Test-Path -LiteralPath $p)){exit}
$bad='.exe','.bat','.cmd','.com','.msi','.ps1','.psm1','.vbs','.vbe','.js','.jse','.wsf','.wsh','.scr','.lnk','.reg','.hta','.jar','.pif','.cpl','.msc','.url','.application','.appref-ms','.gadget','.inf','.dll','.sys','.chm'
$it=Get-Item -LiteralPath $p -Force
if($it.PSIsContainer){ Start-Process explorer.exe -ArgumentList ('"'+$p+'"') }
elseif($bad -contains $it.Extension.ToLower()){ Start-Process explorer.exe -ArgumentList ('/select,"'+$p+'"') }
else{ Start-Process -FilePath $p }
