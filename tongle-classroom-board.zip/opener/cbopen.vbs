' Run cbopen.ps1 hidden
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
If WScript.Arguments.Count < 1 Then WScript.Quit
d = fso.GetParentFolderName(WScript.ScriptFullName)
a = WScript.Arguments(0)
a = Replace(a, """", "")
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & d & "\cbopen.ps1"" """ & a & """", 0, False
