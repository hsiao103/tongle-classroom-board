@echo off
chcp 65001 >nul
set "D=%~dp0"
reg add "HKCU\Software\Classes\cbopen" /ve /d "URL:cbopen" /f >nul
reg add "HKCU\Software\Classes\cbopen" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\cbopen\shell\open\command" /ve /d "wscript.exe \"%D%cbopen.vbs\" \"%%1\"" /f >nul
echo.
echo 已安裝。請不要移動或刪除這個資料夾（cbopen.vbs、cbopen.ps1 要留在原處）。
echo 接著回到班級大屏：設定 → 勾選「已安裝檔案總管開啟器」。
echo 第一次點擊本機路徑時，Chrome 會詢問是否開啟，請勾「一律允許」。
pause
