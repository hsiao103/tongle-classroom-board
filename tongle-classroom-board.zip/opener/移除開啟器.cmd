@echo off
chcp 65001 >nul
reg delete "HKCU\Software\Classes\cbopen" /f >nul
echo 已移除。
pause
